#pragma once

int SaveOutput(double *R, int nodecount, double Time);
